import scala.collection.mutable.ListBuffer
import scala.io.StdIn.readLine

object Main {
 def main(args: Array[String]): Unit = {
   println("Домашнее задание.")
   println()

   println("  - задача а:")
   val phrase = readLine("  Ваша фраза: ")
   println(s"    - i. выведем фразу \"$phrase\" справа налево:")
   println("          " + phrase.reverse)
   println(s"    - ii. переведём фразу \"$phrase\" в нижний регистр:")
   println("          " + phrase.toLowerCase)
   println(s"    - iii. удалим символ \"!\" из фразы \"$phrase\":")
   println("          " + phrase.substring(0,phrase.length-1))
   println(s"    - iv. добавим \"and goodbye python!\" в конец фразы \"$phrase\":")
   println("          " + phrase + "and goodbye python!")
   println()

   println("  - задача b:")
   var sal = readLine("     Укажите годовой доход: ").toInt
   val year_bonus = readLine("     Укажите размер годовой премии (в процентах от годового оклада): ").toFloat
   val food_bonus = readLine("     Укажите размер компенсации за питание (месячный): ").toInt
   val tax = readLine("     Укажите размер налога (в процентах): ").toFloat
   var monthly = ((sal + sal * year_bonus / 100 + food_bonus*12)*(tax / 100)/12).toInt
   println(s"     Ежемесячный оклад сотрудника после вычета налогов: $monthly")

//   var sal = 1000
//   val year_bonus = 100
//   val food_bonus = 20
//   val tax = 40

   println()
   println("  - задача c:")
   // премии/компенсации питания/налоги считаем равными для всех сотрудников, исходя из свойств операций сложения
   // и умножения при нахождении отклонения от средней величины их можно не учитывать
   var sal_list = List(100, 150, 200, 80, 120, 75)
   var mean_sal:Float = sal_list.sum/sal_list.length
   println(s"Средний оклад сотрудника отдела: $mean_sal")
   println("отклонение от средней величины оклада (в %): ")
   for (i <- sal_list) {
     sal = i*12
     var monthly = ((sal + sal * year_bonus / 100 + food_bonus*12)*(tax / 100)/12).toInt
     println("  - сотрудник с окладом = " + i + " ед., отклонение = " + ((((i-mean_sal)/mean_sal)*1000).round.toFloat/10) + "%")
     println("    ежемесячный доход с учетом премий/компенсаций/налогов = " + monthly)
   }

   println()
   println("  - задача d:")
   // Задание я смог понять только в том ключе, что пришёл новый сотрудник, ему нужно установить ЗП и добавить её в список
   // с окладами, а затем вычислить макс. и мин. величину
   val new_empl: Int = 160
   sal_list = sal_list.::(new_empl)
   mean_sal = sal_list.sum/sal_list.length
   println(s"Оклад нового сотрудника: $new_empl")
   println(s"Новый список окладов сотрудников отдела: ${sal_list}")
   println(s"Средний оклад по отделу с учётом нового сотрудника: $mean_sal")
   println(s"Минимальный оклад по отделу: ${sal_list.min}")
   println(s"Максимальный оклад по отделу: ${sal_list.max}")

   println()
   println("  - задача e:")
   val new_empls = List(350, 90)
   for (i <- new_empls) sal_list = sal_list.::(i)
   println(s"Оклады новых сотрудников: $new_empls")
   println(s"Добавим их в общий список и отсортируем оклады по возрастанию: ${sal_list.sorted}")

   println()
   println("  - задача f:")
   val new_empl_1 = 130
   sal_list = sal_list.sorted
   println(s"Оклад нового сотрудника: $new_empl_1")
   var ind = 0
   for (i <- sal_list) if (i <= new_empl_1) ind = sal_list.indexOf(i)
   println(s"Найдём в списке индекс элемента, после которого можно вставить новый оклад так, чтобы сохранился порядок следования элементов. Это элемент с индексом \"$ind\" - ${sal_list(ind)}.")
   //Перезапишем массив, разделив исходный список на 2 части по элементу с найденным индексом, после чего добавим нового
   // сотрудника в конец первой части с меньшими элементами и присоединим к ней вторую часть, где все элементы больше.
   var sl_1 = sal_list.slice(0,ind+1)
   var sl_2 = sal_list.slice(ind+1,sal_list.length)
   sal_list = sl_1 :+ new_empl_1 :++ sl_2
   println(s"Перезапишем массив, разделив исходный список на 2 части по найденному индексу. Сформированный список окладов с новым элементом: $sal_list")

   println()
   println("  - задача g:")
   // зададимся величиной "вилки" от 150 до 250 ед.
   val middle_fork = Vector(150,250)
   println(s"Допустим, что оклад работника уровня MIDDLE лежит в диапазоне от ${middle_fork(0)} ед. до ${middle_fork(1)} ед.")
   println(s"Тогда найдём в списке индексы элементов, лежащих в этом диапазоне. Это сотрудники с номерами и соотв. окладами (см. ниже):")
     for (i <- sal_list) {
     if ((i >= middle_fork(0)) && (i <= middle_fork(1)))
       println("№ " + sal_list.indexOf(i) + " - оклад: " + i + " ед.")
     }

   println()
   println("  - задача h:")
   // необходимо проиндексировать зарплату каждого сотрудника на уровень инфляции – 7%, но я не нашёл нормальных способов округления в Scala
   val sal_list_indexed = sal_list.map(_*1.07)
   println("Проиндексировав оклады каждого сотрудника на уровень инфляции принятый = 7% получим новый список с окладами вида:")
   for (i <- sal_list_indexed) yield print(i+" | ")
   println()

   println()
   println("  - задача i:")
   // теперь нужно проиндексировать зарплаты на процент отклонения от среднего по рынку с учетом уровня специалиста. На вход подается 3 значения средних зарплат (junior, middle и senior)
   val levels = Map("junior"->100, "middle"->160, "senior"->210)
   var sal_list_indexed_max = ListBuffer(0.0) // не понял как в Scala добавлять значения в пустой список, поэтому завёл новый список с первым значением = 0
   println(s"Примем величины средних окладов специалистов разных уровней следующими $levels и по ним проиндексируем оклады до величины не большей \"средняя + 7%\"")
   for (i <- sal_list) {
     if (i <=levels("junior")) {
       println("сотрудник № " + sal_list.indexOf(i) + " - уровень \"junior\", оклад ниже среднего (" + i + "), проиндексировать оклад до величины = " + {
         i * 0.07 + levels("junior")})
       sal_list_indexed_max = sal_list_indexed_max :+ (i * 0.07 + levels("junior"))
     }

     else if (i <= levels("middle")) {
       println("сотрудник № " + sal_list.indexOf(i) + " - уровень \"middle\", оклад ниже среднего (" + i + "), проиндексировать оклад до величины = " + {
         i * 0.07 + levels("middle")})
       sal_list_indexed_max = sal_list_indexed_max :+ (i * 0.07 + levels("middle"))
     }

     else if (i < levels("senior")) {
       println("сотрудник № " + sal_list.indexOf(i) + " - уровень \"senior\", оклад ниже среднего (" + i + "), проиндексировать оклад до величины = " + {
         i * 0.07 + levels("senior")
       })
       sal_list_indexed_max = sal_list_indexed_max :+ (i * 0.07 + levels("senior"))
     }
     else {
       println("сотрудник № " + sal_list.indexOf(i) + " - уровень \"senior\", оклад выше среднего (" + i + "), проиндексировать оклад на величину инфляции 7% = " + {i * 1.07})
       sal_list_indexed_max = sal_list_indexed_max :+ (i * 1.07)
     }
     }
   sal_list_indexed_max = sal_list_indexed_max.slice(1,sal_list_indexed_max.length)
   println(s"Итоговый список проиндексированных окладов выглядит след. образом ")
   for (i <- sal_list_indexed_max) yield print(i+" | ")
   println()

   println()
   println("  - задача l, m:")
   var e = Map(
     Set("Иванов", "Петр") -> sal_list_indexed_max(0),
     Set("Иванов", "Иван") -> sal_list_indexed_max(1),
     Set("Петрова", "Екатерина") -> sal_list_indexed_max(2),
     Set("Голубева", "Мария") -> sal_list_indexed_max(3),
     Set("Голубеев", "Евгений") -> sal_list_indexed_max(4),
     Set("Жидкий", "Петр") -> sal_list_indexed_max(5),
     Set("Грозный", "Александр") -> sal_list_indexed_max(6),
     Set("Сидоров", "Геннадий") -> sal_list_indexed_max(7),
     Set("Коровьев", "Жан") -> sal_list_indexed_max(8),
     Set("Иванов", "Поль") -> sal_list_indexed_max(9)
   )
   println("Получена коллеция Map вида:")
   println(e)
   println()
   println("Информация доступна по ключам, например e(Set(\"Голубева\", \"Мария\")) = " + e(Set("Голубева", "Мария")))
   println()

   for (i <- e.keys) {
     if (e(i) == e.values.min) {
       println(s"Минимальный оклад у сотруддника $i - ${e(i)}")

       val sec = i.toList(0).toLowerCase().reverse
       print("\"Запутанный\" вид: ")
       println(s"${
         for (x <- sec.toString)
           if (x.toString != "а" &
             x.toString != "е" &
             x.toString != "ё" &
             x.toString != "о" &
             x.toString != "и" &
             x.toString != "у" &
             x.toString != "ы" &
             x.toString != "я" &
             x.toString != "э" &
             x.toString != "ю" &
             x.toString != "")
             print(s"$x")} - ${e(i)}")
     }
     if (e(i) == e.values.max) {
       println(s"Максимальный оклад у сотруддника $i - ${e(i)}")

       val sec = i.toList(0).toLowerCase().reverse
       print("\"Запутанный\" вид: ")
       println(s"${
         for (x <- sec.toString)
           if (x.toString != "а" &
             x.toString != "е" &
             x.toString != "ё" &
             x.toString != "о" &
             x.toString != "и" &
             x.toString != "у" &
             x.toString != "ы" &
             x.toString != "я" &
             x.toString != "э" &
             x.toString != "ю" &
             x.toString != "")
             print(s"$x")
       } - ${e(i)}")
       println()
     }
   }

   println()
   println("  - задача o:")
   //не совсем разобрался с хвостовой рекурсией, но по-моему в решении ниже она убрана с пом. добавления счётчика,
   // хранящего результат вычисления предыдущего шага цикла, в итоге получается, что нет длинной последовательности
   // произведений "2", которые нужно раскручивать "с хвоста" и которые рано или поздно переполнят стэк, но это моё
   // предположение, я другого варианта кроме приведённого ниже не тестировал
   def power_2(n:Int) = {
     assert(n>=0, "Ожидается ввод положительного целого N, т.к. рассчитавается число 2 в натуральной степени (не дробной и не отрицательной)")
     assert(n<1000000, "Слишком большой показатель степени N, расчёт занимает много времени")
     var i = 1
     var acc:BigInt = 1 // натуральные степени 2 быстро превосходят объём числа, которое может храниться в Int или Long, добавим BigInt
     while (i<=n) {
       acc *= 2
       i += 1
     }
     acc
   }

   var result = power_2(50000)
   println("Проверка: 2 в степени 50 000 =")
   println(result)

   println("Длина числа в битах = ")
   println(result.bitLength)
 }
}